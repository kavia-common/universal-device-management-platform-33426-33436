import type { Meta, StoryObj } from '@storybook/angular';
import { LabeledInfoRowComponent } from './labeled-info-row.component';

const meta: Meta<LabeledInfoRowComponent> = {
  title: 'Components/LabeledInfoRow',
  component: LabeledInfoRowComponent,
  tags: ['autodocs'],
  render: (args: LabeledInfoRowComponent) => ({
    props: args
  }),
  decorators: [
    (story) => ({
      template: `
        <div class="p-6 bg-surface">
          <div class="text-xs text-muted mb-3">Using Tailwind utilities in Storybook.</div>
          <div class="max-w-md">
            <story/>
          </div>
        </div>
      `,
      props: story().props
    })
  ]
};
export default meta;

type Story = StoryObj<LabeledInfoRowComponent>;

export const Default: Story = {
  args: {
    label: 'IP Address:',
    value: '192.168.1.100',
    soft: true,
    radius: '8'
  }
};

export const EmphasizedValue: Story = {
  args: {
    label: 'Product Class:',
    value: 'Router',
    valueColor: 'var(--udm-color-primary)',
    soft: true,
    radius: '8'
  }
};
