import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * PUBLIC_INTERFACE
 * LabeledInfoRowComponent
 * Compact card with a label and corresponding value, following the design's info-card style.
 */
@Component({
  selector: 'udm-labeled-info-row',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './labeled-info-row.component.html',
  styleUrls: ['./labeled-info-row.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LabeledInfoRowComponent {
  /** Small label above/beside the value (e.g., "IP Address:") */
  // PUBLIC_INTERFACE
  @Input() label: string = '';

  /** Value text (e.g., "192.168.1.100") */
  // PUBLIC_INTERFACE
  @Input() value: string = '';

  /** Optional color for value (CSS color or var) */
  // PUBLIC_INTERFACE
  @Input() valueColor?: string;

  /** Whether to render with soft surface background */
  // PUBLIC_INTERFACE
  @Input() soft: boolean = true;

  /** Border radius size */
  // PUBLIC_INTERFACE
  @Input() radius: '6'|'8' = '8';
}
