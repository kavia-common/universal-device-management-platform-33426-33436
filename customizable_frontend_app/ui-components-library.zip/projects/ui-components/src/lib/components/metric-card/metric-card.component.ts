import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * PUBLIC_INTERFACE
 * MetricCardComponent
 * A themeable card showing an icon, label, main value, and optional tag/subtext/progress bar.
 */
@Component({
  selector: 'udm-metric-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './metric-card.component.html',
  styleUrls: ['./metric-card.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MetricCardComponent {
  /** Icon name from Material Icons or custom */
  // PUBLIC_INTERFACE
  @Input() icon: string = 'info';

  /** Label displayed near icon (e.g., "CPU Utilization") */
  // PUBLIC_INTERFACE
  @Input() label: string = '';

  /** Main value text (e.g., "23%") */
  // PUBLIC_INTERFACE
  @Input() value: string = '';

  /** Optional tag chip text (e.g., "Normal") */
  // PUBLIC_INTERFACE
  @Input() tag?: string;

  /** Tag background color (CSS color or var). Defaults to primary accent. */
  // PUBLIC_INTERFACE
  @Input() tagColor: string = 'var(--udm-color-accent)';

  /** Optional subtext, shown near value (e.g., "(512GB / 1024GB)") */
  // PUBLIC_INTERFACE
  @Input() subtext?: string;

  /** If set, show a progress bar with this percentage (0-100). */
  // PUBLIC_INTERFACE
  @Input() progress?: number;

  /** Color of left header (icon/label) and accents. */
  // PUBLIC_INTERFACE
  @Input() toneColor: string = 'var(--udm-color-primary-strong)';

  /** Elevation (shadow level) */
  // PUBLIC_INTERFACE
  @Input() elevation: 'none'|'low'|'mid' = 'low';

  get classes() {
    return {
      'elev-none': this.elevation === 'none',
      'elev-low': this.elevation === 'low',
      'elev-mid': this.elevation === 'mid',
    };
  }
}
