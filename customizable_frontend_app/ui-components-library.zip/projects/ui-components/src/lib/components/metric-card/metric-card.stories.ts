import type { Meta, StoryObj } from '@storybook/angular';
import { MetricCardComponent } from './metric-card.component';
import { MatButtonModule } from '@angular/material/button';

const meta: Meta<MetricCardComponent> = {
  title: 'Components/MetricCard',
  component: MetricCardComponent,
  tags: ['autodocs'],
  render: (args: MetricCardComponent) => ({
    props: args
  }),
  decorators: [
    // Example: show Tailwind utility and Material button usage next to the component
    (story) => ({
      template: `
        <div class="p-4 space-y-4 bg-surface">
          <div class="text-sm text-muted">Material + Tailwind available in Storybook preview.</div>
          <div class="flex items-center gap-3">
            <button mat-raised-button color="primary">Material Button</button>
            <button mat-stroked-button>Secondary</button>
            <span class="px-3 py-1 rounded-full bg-primary text-white text-xs">Tailwind Badge</span>
          </div>
          <div class="max-w-md">
            ${story().template || '<story/>'}
          </div>
        </div>
      `,
      props: story().props,
      moduleMetadata: {
        imports: [MatButtonModule],
      }
    })
  ]
};
export default meta;

type Story = StoryObj<MetricCardComponent>;

export const Uptime: Story = {
  args: {
    icon: 'timer',
    label: 'Uptime:',
    value: '7 days, 14 hours',
    toneColor: 'var(--udm-color-primary-strong)',
    elevation: 'low'
  }
};

export const TemperatureWithTag: Story = {
  args: {
    icon: 'thermostat',
    label: 'Temperature:',
    value: '45°C',
    tag: 'Normal',
    tagColor: 'var(--udm-color-accent)',
    toneColor: 'var(--udm-color-primary-strong)',
    elevation: 'low'
  }
};

export const CpuWithProgress: Story = {
  args: {
    icon: 'memory',
    label: 'CPU Utilization:',
    value: '23%',
    progress: 23,
    toneColor: 'var(--udm-color-primary-strong)',
    elevation: 'low'
  }
};

export const MemoryWithSubtext: Story = {
  args: {
    icon: 'storage',
    label: 'Memory Usage:',
    value: '512GB',
    subtext: '(512GB / 1024GB)',
    toneColor: 'var(--udm-color-primary-strong)',
    elevation: 'low'
  }
};
